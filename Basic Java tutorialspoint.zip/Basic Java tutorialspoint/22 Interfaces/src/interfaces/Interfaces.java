package interfaces;

public class Interfaces {

    public static void main(String[] args) {

    }

}
