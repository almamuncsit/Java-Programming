package interfaces;

interface Animal {
   public void eat();
   public void travel();
}