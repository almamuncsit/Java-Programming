/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pkg06.condition;

/**
 *
 * @author mamun
 */
public class ifElseCondition {
    public static void main(String[] args) {
        System.out.println("Nice ");
        int a = 5;
        if (a == 5) {
            System.out.println("A is 5");
        } else {
            System.out.println("A is not 5");
        }
    }
}
