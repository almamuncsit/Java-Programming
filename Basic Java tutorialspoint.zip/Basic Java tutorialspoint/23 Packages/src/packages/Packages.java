package packages;

import test.Test;

public class Packages {

    public static void main(String[] args) {
        Test tst = new Test();
        tst.display();
    }

}
