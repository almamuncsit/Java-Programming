
package test;

public class Test {
    public void display() {
        System.out.println("How are you Boss. ");
    }
}
