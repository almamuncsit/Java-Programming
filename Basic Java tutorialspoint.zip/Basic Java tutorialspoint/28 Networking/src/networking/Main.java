package networking;

public class Main {

    public static void main(String[] args) {
        URLDemo url = new URLDemo();
        url.view();

        System.out.println("Url Connection : ");
        URLConnDemo urlCoD = new URLConnDemo();
    }

}
