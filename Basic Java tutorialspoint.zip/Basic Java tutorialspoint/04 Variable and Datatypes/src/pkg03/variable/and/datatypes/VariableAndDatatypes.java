
package pkg03.variable.and.datatypes;


public class VariableAndDatatypes {

    public void pupAge(){
      int age = 0;
      age = age + 7;
      System.out.println("Puppy age is : " + age);
   }
   
   public static void main(String args[]){
      VariableAndDatatypes test = new VariableAndDatatypes();
      test.pupAge();
   }
    
}
