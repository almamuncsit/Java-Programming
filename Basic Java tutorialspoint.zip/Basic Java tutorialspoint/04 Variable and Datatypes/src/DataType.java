
public class DataType {

    public static void main(String[] args) {
        int p, q, r;         // Declares three ints, a, b, and c.
        int a = 10, b = 10;  // Example of initialization
        byte B = 22;         // initializes a byte type variable B.
        double pi = 3.14159; // declares and assigns a value of PI.
        char c = 'a';
        
        System.out.println("Char \t: " + c);
        System.out.println("Byte \t: " + B);
        System.out.println("Pi \t: " + pi);
        
    }
}
