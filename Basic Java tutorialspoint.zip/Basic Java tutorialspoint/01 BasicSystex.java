/**
 *
 * @author User
 */
public class BasicSyntax {
    
    public static void main(String[] args) {
        System.out.println("Hello word");
    }
    
}