
package collectionsframework;
import java.util.*;

public class TreeSetDemo {
    public static void main(String[] args) {
        TreeSet ts = new TreeSet();
        ts.add("p");
        ts.add("a");
        ts.add("r");
        System.out.println(ts);
    }
}
