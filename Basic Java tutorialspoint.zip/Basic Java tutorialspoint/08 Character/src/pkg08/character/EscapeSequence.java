
package pkg08.character;

public class EscapeSequence {
    public static void main(String[] args) {
        System.out.println("Tab : \t value");
        System.out.println("Backspace : \b value");
        System.out.println("New Line: \n value");
        
        System.out.println("Carriage: \r value");
        
        System.out.println("feed\fvalue");
        
        System.out.println("hello\'s value");
        System.out.println("hello\" value");
        System.out.println("hello\\value");
    }
}
