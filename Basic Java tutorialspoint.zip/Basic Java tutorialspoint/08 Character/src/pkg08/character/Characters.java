
package pkg08.character;


public class Characters {
    
    public static void main(String[] args) {
        char a = 'a';
        System.out.println(a);
        
        char uniChar = '\u039A';
        System.out.println(uniChar);
        
        char[] charArray = {'a', 'b', 'c', 'd'};
        System.out.println(charArray[1]);
        
        
        Character ch = new Character('a');
        System.out.println(ch);
    }
    
}
