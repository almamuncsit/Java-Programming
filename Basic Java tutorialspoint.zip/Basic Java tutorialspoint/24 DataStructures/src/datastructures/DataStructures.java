package datastructures;

public class DataStructures {

    public static void main(String[] args) {

    }

}
